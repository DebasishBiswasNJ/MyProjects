package com.game;

import javax.swing.JFrame;

import com.gamePlay.GamePlay;

public class MainClass {

	public static void main(String[] args) {
		
		GamePlay gamePlay = new GamePlay();
		JFrame jf = new JFrame();
		jf.setBounds(10, 10, 700, 600);
		jf.setTitle("Breaking the Bricks");
		jf.setResizable(false);
		jf.setVisible(true);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		jf.add(gamePlay);
	}

}
